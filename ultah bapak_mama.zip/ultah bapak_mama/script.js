```javascript
const music = document.getElementById("bgMusic");
const musicButton = document.getElementById("musicButton");

let isPlaying = false;


// ================================
// MUSIC
// ================================

musicButton.addEventListener("click", function () {

    if (isPlaying) {

        music.pause();

        musicButton.innerHTML = "♪";

        isPlaying = false;

    } else {

        music.play();

        musicButton.innerHTML = "❚❚";

        isPlaying = true;

    }

});


// ================================
// START BUTTON
// ================================

function scrollToStory() {

    document.getElementById("story").scrollIntoView({
        behavior: "smooth"
    });

    // mencoba memainkan musik setelah user melakukan klik
    music.play()
        .then(() => {

            isPlaying = true;
            musicButton.innerHTML = "❚❚";

        })
        .catch(() => {

            console.log("Musik belum dapat diputar.");

        });

}


// ================================
// FADE-IN SECTION
// ================================

const sections = document.querySelectorAll(
    ".birthday-card, .photo-section, .gallery-section, .letter, .closing-content"
);

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";

            }

        });

    },
    {
        threshold: 0.15
    }
);


sections.forEach(section => {

    section.style.opacity = "0";

    section.style.transform = "translateY(25px)";

    section.style.transition =
        "opacity 1s ease, transform 1s ease";

    observer.observe(section);

});
```
